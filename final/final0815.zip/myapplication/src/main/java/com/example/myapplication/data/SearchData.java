package com.example.myapplication.data;

public class SearchData {

    public SearchData() {}

}
